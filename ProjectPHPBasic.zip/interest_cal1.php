<?php
// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $principal = $_POST['principal']; //เงินต้น
    $installment_monthly = $_POST['installment_monthly']; //จำนวนเงินที่ต้องการจ่ายต่อเดือน
    $interest_rate = $_POST['interest_rate']; //อัตราดอกเบี้ย
    $installment_amount = $_POST['installment_amount']; //จำนวนงวดทั้งหมด(เดือน)

    // Test code
    // $interest_in_month = ($principal * ($interest_rate / 100) * 30) / 365; 
    // $principal_decrease = $installment_monthly - $interest_in_month; 
    // $principal_balance = $principal - $principal_decrease; 

    // echo $interest_in_month . "<br>";
    // echo $principal_decrease . "<br>";
    // echo $principal_balance . "<br>";

    // $interest_in_month2 = ($principal_balance * ($interest_rate / 100) * 30) / 365;
    // $principal_decrease2 = $installment_monthly - $interest_in_month2; 
    // $principal_balance2 = $principal_balance - $principal_decrease2;

    // echo $interest_in_month2 . "<br>";
    // echo $principal_decrease2 . "<br>";
    // echo $principal_balance2 . "<br>";

    $i = 1;
    $interest_sum = 0;
    $x = 0;
    while($i <= $installment_amount) {
      $interest_in_month = ($principal * ($interest_rate / 100) * 30) / 365; //ดอกเบี้ยที่ต้องจ่ายในงวดนั้น
      $principal_decrease = $installment_monthly - $interest_in_month; //เงินต้นลดลง
      $principal_balance = $principal - $principal_decrease; //เงินต้นคงเหลือ
      $principal = $principal_balance;
      $interest_sum = $interest_sum + $interest_in_month;
      $x = $x + $principal_decrease;
      
      // echo $i . " i<br>";
      // echo $principal . " เงินต้น<br>";
      // echo $interest_in_month . " ดอกเบี้ยที่ต้องจ่ายในงวดนั้น<br>";
      // echo $principal_decrease . " เงินต้นลดลง<br>";
      // echo $principal_balance . " เงินต้นคงเหลือ<br>";
      // echo $interest_sum . " ดอกเบี้ยทั้งหมด<br><br>";
      $i++;
    }

    // echo " เงินต้น " . ($x + $principal_balance) . " บาท<br>";
    // echo " จ่ายเดือนละ " . $installment_monthly . " บาท<br>";
    // echo " อัตราดอกเบี้ย " . $interest_rate . " % ต่อปี<br>";
    // echo " จ่ายทั้งหมด " . $installment_amount . " เดือน<br>";

    // echo " ดอกเบี้ยทั้งหมด " . $interest_sum . " บาท<br>";
    // echo " ยอดเงินรวมทั้งหมดที่ต้องจ่าย " . ($x + $principal_balance + $interest_sum) . " บาท<br>";
}
?>