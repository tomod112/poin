<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $age_current = $_POST['age_current'];
        $age_retir = $_POST['age_retir'];
        $age_end = $_POST['age_end'];
        $retirement_money = $_POST['retirement_money'];

    $time_saving = $age_retir - $age_current; 
    $time_use = $age_end - $age_retir;
    $amount_collected = $time_use * 12 * $retirement_money;
    $saving_monthly = $amount_collected / $time_saving / 12; 

    // echo $time_saving . " มีเวลาเก็บเงินอีก...ปี<br>"; //มีเวลาเก็บเงินอีก...ปี
    // echo $time_use . " เวลาที่ต้องการใช้เงิน...ปี<br>"; //เวลาที่ต้องการใช้เงิน...ปี
    // echo $amount_collected . " เงินที่ต้องเก็บทั้งหมด...บาท<br>"; //เงินที่ต้องเก็บทั้งหมด...บาท
    // echo $saving_monthly . " เงินที่ต้องเก็บต่อเดือน...บาท<br>"; //เงินที่ต้องเก็บต่อเดือน...บาท
    }
?> 