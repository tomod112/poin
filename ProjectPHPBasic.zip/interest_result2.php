<?php

    include("interest_cal2.php")

?>

<!doctype html>
<html lang="en">

<head>

    <header>
        <?php include("head.php"); ?>
    </header>

</head>

<body>

    <header>
        <?php include("header.php"); ?>
    </header>

    <section>
        <br>
        <div class="container">
            <div class="row">
                <div class="col">

                </div>
                <div class="col-6">

                    <div class=" bg-primary bg-gradient text-bg-primary bg-opacity-75 text-start">
                        <br>
                        <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ผลการคำนวณดอกเบี้ยแบบคงที่</h3><br>
                    </div>
                    <div class="border border-4 border-top-0">
                        <br>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h6 ">จำนวนเงินต้น</p>
                            <p class="col-sm-6 text-start h5"><?php echo number_format($principal, 2) . " บาท<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h6 ">อัตราดอกเบี้ย</p>
                            <p class="col-sm-6 text-start h5"><?php echo $interest_rate . " % ต่อปี<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h6 ">จำนวนงวดทั้งหมด</p>
                            <p class="col-sm-6 text-start h5"><?php echo $installment_amount . " เดือน<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p>***********************************************************************</p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h5 ">ดอกเบี้ยรวมทั้งหมด</p>
                            <p class="col-sm-6 text-start h5"><?php echo number_format($total_Interest, 2) . " บาท<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h5 ">เงินผ่อนชำระต่อเดือน</p>
                            <p class="col-sm-6 text-start h5">
                                <?php echo number_format($installment_monthly,2) . " บาท<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h5 ">เงินที่ชำระทั้งหมดรวมดอกเบี้ย</p>
                            <p class="col-sm-6 text-start h5"><?php echo number_format(($principal + $total_Interest), 2) . " บาท<br>"; ?>
                            </p>
                            <br><br>
                        </div>
                        <div class="row ">
                            <div class="col-1">
                            </div>
                            <div class="col-10 alert alert-primary " role="alert">
                                <p>หมายเหตุ</p>
                                <p>
                                    อัตราดอกเบี้ยแบบคงที่จะคิดอัตราดอกเบี้ยครั้งเดียวตั้งแต่วันที่เริ่มถึงวันที่ผ่อนแล้วเสร็จ
                                    หลังจากนั้นจับหารด้วยจํานวนงวดที่หารเลย
                                </p>
                            </div>
                            <div class="col-1">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">

                </div>
            </div>
        </div>

        <br><br><br><br><br><br>
    </section>

    <footer>
        <?php
            include("footer.php");
        ?>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>