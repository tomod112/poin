<?php

    include("savings_cal.php")

?>

<!doctype html>
<html lang="en">

<head>

    <header>
        <?php include("head.php"); ?>
    </header>

</head>

<body>

    <header>
        <?php include("header.php"); ?>
    </header>
    
    <section>
        <br>
        <div class="container">
            <div class="row">
                <div class="col">

                </div>
                <div class="col-6">

                    <div class=" bg-warning bg-gradient text-bg-warning bg-opacity-75 text-start">
                        <br>
                        <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ผลการคำนวณเงินฝาก</h3><br>
                    </div>
                    <div class="border border-4 border-top-0">
                        <br>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h6 ">เงินออมต่อเดือน</p>
                            <p class="col-sm-6 text-start h5"><?php echo number_format($savings_monthly, 2) . " บาท<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h6 ">อัตราดอกเบี้ย</p>
                            <p class="col-sm-6 text-start h5"><?php echo $interest_rate . " % ต่อปี<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h6 ">ต้องการออม</p>
                            <p class="col-sm-6 text-start h5"><?php echo $interest_term . " ปี<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p>***********************************************************************</p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h5 ">เงินต้นทั้งหมด</p>
                            <p class="col-sm-6 text-start h5"><?php echo number_format($total_saving, 2) . " บาท<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h5 ">ดอกเบี้ยทั้งหมด</p>
                            <p class="col-sm-6 text-start h5">
                                <?php echo number_format($x - $total_saving, 2) . " บาท<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h5 ">ยอดเงินฝากที่ครบตามปีที่ออม</p>
                            <p class="col-sm-6 text-start h5"><?php echo number_format($x, 2) . " บาท<br>"; ?></p>
                            <br><br>
                        </div>
                        <div class="row ">
                            <div class="col-1">
                            </div>
                            <div class="col-10 alert alert-warning " role="alert">
                                หมายเหตุ เป็นการคิดแบบดอกเบี้ยแบบทบต้นต่อเดือน
                            </div>
                            <div class="col-1">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">

                </div>
            </div>
        </div>

        <br><br><br><br><br><br>
    </section>

    <footer>
        <?php include("footer.php"); ?>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>