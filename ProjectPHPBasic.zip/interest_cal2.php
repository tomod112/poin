<?php
// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    $principal = $_POST['principal']; //เงินต้น
    $interest_rate = $_POST['interest_rate']; //อัตราดอกเบี้ย
    $installment_amount = $_POST['installment_amount']; //จำนวนงวดทั้งหมด(เดือน)

    $total_Interest = $principal * $interest_rate / 100; //ดอกเบี้ยที่ต้องจ่ายทั้งหมด
    $installment_monthly = ($principal + $total_Interest) / $installment_amount; //เงินผ่อนชำระต่อเดือน


    // echo "จำนวนเงินต้น " . $principal . " บาท<br>";
    // echo "อัตราดอกเบี้ย " . $interest_rate . " % ต่อปี<br>";
    // echo "จำนวนงวดทั้งหมด " . $installment_amount . " เดือน<br>";

    // echo "จำนวนดอกเบี้ยที่ต้องจ่ายทั้งหมด " . $total_Interest . " บาท<br>";
    // echo "จำนวนเงินผ่อนชำระต่อเดือน " . $installment_monthly . " บาท<br>";
    // echo "จำนวนเงินที่ต้องชำระทั้งหมด " . ($principal + $total_Interest) . " บาท<br>";
    
}
?>