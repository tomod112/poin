<!doctype html>
<html lang="en">

<head>

    <header>
        <?php include("head.php"); ?>
    </header>

</head>

<body>

    <header>
        <?php include("header.php"); ?>
    </header>

    <section>
        <br>
        <div class="container text-center">
            <div class="row">
                <div class="col">
                </div>
                <div class="col-6">
                    <div class="p-3 mb-2 bg-dark text-white">
                        <div class="p-3 mb-2 bg-light text-dark h2">เรื่องของการเงิน</div>
                    </div>
                    <br>
                    <div class="list-group">
                        <a href="retir.php" class="list-group-item list-group-item-action">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1">ออมเงินเท่าไหร่พอใช้เกษียณ</h5>
                                <small class="text-muted">คำนวณ คลิก!</small>
                            </div>
                            <p class="mb-1">เกษียณ</p>
                            <small class="text-muted">คำที่บอกจุดเปลี่ยนสำคัญในชีวิตว่า คนเรามีเวลาหาเงินกับใช้เงินไม่เท่ากัน โดยเฉลี่ยคนไทยเมื่อก้าวเข้าสู่วัยทำงานตอนอายุ 20 ปีจะมีเวลาหาเงิน 40 ปีและมีเวลาใช้เงิน 60 ปี จึงทำให้ผู้สูงอายุเกินครึ่งมีเงินไม่พอใช้หลังเกษียณ เพราะเวลาใช้เงินยาวนานกว่าหาเงินถึง 20 ปี ต้องใช้ชีวิตลำบากยามที่ร่างกายอ่อนแรง สำหรับคนรุ่นใหม่อายุยังไม่มากมองเกษียณเป็นเรื่องไกลตัว แต่ท่านรู้หรือไม่ว่าเวลาผ่านไปเร็วกว่าที่คิด พอถึงวันใกล้เกษียณก็เก็บเงินไม่ทันซะแล้ว</small>
                        </a>
                        <br>
                        <a href="savings.php" class="list-group-item list-group-item-action">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1">เงินฝาก</h5>
                                <small class="text-muted">คำนวณ คลิก!</small>
                            </div>
                            <p class="mb-1"> การออม</p>
                            <small class="text-muted">​เป็นการแบ่งรายได้ส่วนหนึ่งเก็บสะสมไว้สำหรับวัตถุประสงค์ต่าง ๆ เช่น เพื่อไว้ใช้ในอนาคต เผื่อเวลาฉุกเฉิน เพื่อใช้ในสิ่งที่อยากได้หรืออยากทำ การออมส่วนใหญ่มักอยู่ในรูปแบบที่มีความเสี่ยงต่อการสูญเสียเงินต้นต่ำ และได้รับผลตอบแทนไม่สูงนักเมื่อเทียบกับการลงทุน เช่น การฝากออมทรัพย์ การฝากประจำ การซื้อสลากออมทรัพย์</small>
                        </a>
                        <br>
                        <a href="interest_fixed.php" class="list-group-item list-group-item-action">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1">ดอกเบี้ยแบบคงที่</h5>
                                <small class="text-muted">คำนวณ คลิก!</small>
                            </div>
                            <p class="mb-1">ดอกเบี้ยคงที่ (Flat Rate)</p>
                            <small class="text-muted">ดอกเบี้ยที่คำนวณจากเงินต้นทั้งก้อนตั้งแต่วันที่ทำสัญญา แล้วนำไปหารกับจำนวนงวดที่ต้องผ่อน ทำให้ต้องจ่ายดอกเบี้ยเท่าเดิมในทุก ๆ งวด ถึงแม้จะมีการผ่อนชำระไปบางส่วนแล้ว ดอกเบี้ยก็จะไม่ลดน้อยลง ซึ่งส่วนใหญ่แล้วดอกเบี้ยแบบคงที่มักจะใช้กับการกู้ยืมเพื่อซื้อรถยนต์</small>
                        </a>
                        <br>
                        <a href="interest_effective_rate.php" class="list-group-item list-group-item-action">
                            <div class="d-flex w-100 justify-content-between">
                                <h5 class="mb-1">ดอกเบี้ยแบบลดต้นลดดอก</h5>
                                <small class="text-muted">คำนวณ คลิก!</small>
                            </div>
                            <p class="mb-1">ดอกเบี้ยลดต้นลดดอก (Effective Rate)</p>
                            <small class="text-muted">ดอกเบี้ยที่คำนวณจากเงินต้นที่เหลือในทุก ๆ งวด ทำให้เมื่อมีการผ่อนชำระบางส่วนไปแล้ว ดอกเบี้ยที่ต้องชำระในงวดถัดไปก็จะน้อยลงเรื่อย ๆ ขึ้นอยู่กับจำนวนเงินต้นที่เหลือ</small>
                        </a>
                    </div>
                </div>
                <div class="col">
                </div>
            </div>
        </div>

        <br><br><br><br><br><br>
    </section>

    <footer>
        <?php
            include("footer.php");
        ?>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>