<?php
// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  
  $savings_monthly = $_POST['savings_monthly'];
  $interest_term = $_POST['interest_term'];
  $interest_rate = $_POST['interest_rate'];

  $interest_term_month = $interest_term * 12;
  $total_saving = $savings_monthly * $interest_term_month;
  $monthly_payment = 0;

  $i = 1;
  while($i <= $interest_term_month) {
    $x = ($monthly_payment + $savings_monthly) * (($interest_rate / 1200) + 1);
    $monthly_payment = $x;
    $i++;
  }

  $y = $x;

  // echo "เงินออมต่อเดือน $savings_monthly บาท<br>";
  // echo "อัตราดอกเบี้ย $interest_rate %<br>";
  // echo "ต้องการออม $interest_term ปี<br>";
  // echo "เงินต้นทั้งหมดเมื่อครบตามปีที่ออม $total_saving บาท<br>";
  // echo "ดอกเบี้ยทั้งหมดเมื่อครบตามปีที่ออม " . number_format($x - $total_saving, 2) . " บาท<br>";
  // echo "ยอดเงินฝากสุทธิเมื่อครบตามปีที่ออม " . number_format($x, 2) . " บาท<br><br>";
  // echo " หมายเหตุ เป็นการคิดแบบดอกเบี้ยทบต้นต่อเดือน ";
}
?>