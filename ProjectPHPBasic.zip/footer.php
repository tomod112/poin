<footer>
        <div class="text-bg-dark p-3 text-center">
            <div class="container">
                <div class="row">
                    <div class="col-sm-4">
                        <h5> Copyright &copy; 2022 <br> All Right Reserved Panuwat Inthapong</h5>
                    </div>
                    <div class="col-sm-4">
                        <h5>Project PHP Basic</h5>
                    </div>
                    <div class="col-sm-4">
                        <h4>Follow us on social media:</h4>
                        <a href="https://www.facebook.com" target="_blank"><i
                                class="fab fa-facebook-square fa-2x"></i></a>
                        <a href="https://twitter.com" target="_blank"><i
                                class="fab fa-twitter-square fa-2x"></i></a>
                        <a href="https://www.instagram.com" target="_blank"><i
                                class="fab fa-instagram-square fa-2x"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </footer>