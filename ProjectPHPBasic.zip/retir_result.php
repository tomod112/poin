<?php

    include("retir_cal.php")

?>

<!doctype html>
<html lang="en">

<head>

    <header>
        <?php include("head.php"); ?>
    </header>

</head>

<body>

    <header>
        <?php include("header.php"); ?>
    </header>

    <section>
        <br>
        <div class="container">
            <div class="row">
                <div class="col">

                </div>
                <div class="col-6">

                    <div class=" bg-secondary bg-gradient text-bg-secondary bg-opacity-75 text-start">
                        <br>
                        <h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;ผลการคำนวณเงินออมเพื่อการเกษียณ</h3><br>
                    </div>
                    <div class="border border-4 border-top-0">
                        <br>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h6 ">อายุปัจจุบัน</p>
                            <p class="col-sm-6 text-start h5"><?php echo $age_current . " ปี<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h6 ">อายุตอนเกษียณ</p>
                            <p class="col-sm-6 text-start h5"><?php echo $age_retir . " ปี<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h6 ">อายุที่คิดว่าจะสิ้นอายุขัย</p>
                            <p class="col-sm-6 text-start h5"><?php echo $age_end . " ปี<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h6 ">จำนวนเงินที่จะใช้หลังเกษียณต่อเดือน</p>
                            <p class="col-sm-6 text-start h5"><?php echo number_format($retirement_money, 2) . " บาท<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p>***********************************************************************</p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h5 ">มีเวลาเก็บเงินอีก</p>
                            <p class="col-sm-6 text-start h5">
                                <?php echo $time_saving . " ปี<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h5 ">เวลาที่ต้องการใช้เงิน</p>
                            <p class="col-sm-6 text-start h5">
                                <?php echo $time_use . " ปี<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h5 ">เงินที่ต้องเก็บทั้งหมด</p>
                            <p class="col-sm-6 text-start h5">
                                <?php echo number_format($amount_collected, 2) . " บาท<br>"; ?></p>
                        </div>
                        <div class="row text-center ">
                            <p class="col-sm-6 text-end h5 ">เงินที่ต้องเก็บต่อเดือน</p>
                            <p class="col-sm-6 text-start h5">
                                <?php echo number_format($saving_monthly, 2) . " บาท<br>"; ?></p>
                        </div>
                        <div class="row ">
                            <div class="col-1">
                            </div>
                            <div class="col-10 alert alert-secondary " role="alert">
                                หมายเหตุ เป็นการคิดแบบดอกเบี้ยแบบทบต้นต่อเดือน
                            </div>
                            <div class="col-1">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">

                </div>
            </div>
        </div>

        <br><br><br><br><br><br>
    </section>

    <footer>
        <?php include("footer.php"); ?>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>