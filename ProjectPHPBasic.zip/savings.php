<!doctype html>
<html lang="en">

<head>

    <header>
        <?php include("head.php"); ?>
    </header>

</head>

<body>

    <header>
        <?php include("header.php"); ?>
    </header>

    <section>
        <br>
        <div class="container">
            <div class="row">
                <div class="col">
                </div>
                <div class="col-6">
                    <br>
                    <div class="alert text-bg-warning bg-gradient text-center " role="alert">
                        <h4>คำนวณหายอดเงินออมทั้งหมดเมื่อครบกำหนด</h4>
                    </div>
                    <form action="savings_result.php" method="post">
                        <div class="mb-3">
                            <label class="form-label">จำนวนเงินที่ต้องการออม (บาทต่อเดือน)</label>
                            <input name="savings_monthly" class="form-control" type="text" placeholder="บาท"
                                aria-label="default input example">
                            
                        </div>
                        <div class="mb-3">
                            <label class="form-label">ระยะเวลาที่ลงทุน (ปี)</label>
                            <input name="interest_term" class="form-control" type="text" placeholder="ปี"
                                aria-label="default input example">
                            
                        </div>
                        <div class="mb-3">
                            <label class="form-label">อัตราดอกเบี้ย (% ต่อปี)</label>
                            <input name="interest_rate" class="form-control" type="text" placeholder="% ต่อปี"
                                aria-label="default input example">
                            
                        </div>
                        <button type="submit" class="btn btn-warning">คำนวณ</button>
                    </form>
                </div>
                <div class="col">

                </div>
            </div>
        </div>
        <br><br><br><br><br><br>
    </section>

    <footer></footer>
    <?php include("footer.php"); ?>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous">
    </script>
</body>

</html>